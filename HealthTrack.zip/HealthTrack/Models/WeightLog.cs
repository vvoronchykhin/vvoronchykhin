﻿using System;

namespace HealthTrack.Models
{
    public class WeightLog
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public DateTime Date { get; set; }
        public decimal Weight { get; set; }
    }
}