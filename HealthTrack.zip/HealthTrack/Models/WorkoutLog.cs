﻿using System;

namespace HealthTrack.Models
{
    public class WorkoutLog
    {
        public Guid Id { get; set; }
        public Guid WorkoutPlanId { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan Duration { get; set; }
    }
}
