﻿using System;

namespace HealthTrack.Models
{
    public class Exercise
    {
        public Guid Id { get; set; } // Первичный ключ
        public string Name { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
    }
}