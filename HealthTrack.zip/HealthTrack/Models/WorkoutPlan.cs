﻿using System;

namespace HealthTrack.Models
{
    public class WorkoutPlan
    {
        public Guid Id { get; set; }
        public string UserId { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
    }
}