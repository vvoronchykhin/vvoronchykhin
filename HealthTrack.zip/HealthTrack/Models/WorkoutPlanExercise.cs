﻿using System;

namespace HealthTrack.Models
{
    public class WorkoutPlanExercise
    {
        public Guid Id { get; set; }
        public Guid WorkoutPlanId { get; set; }
        public Guid ExerciseId { get; set; }
        public int Sets { get; set; }
        public int Reps { get; set; }
        public decimal Weight { get; set; }
    }
}