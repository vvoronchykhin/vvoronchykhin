﻿using System;
using System.ComponentModel.DataAnnotations; // Для атрибутов валидации

namespace HealthTrack.Models.DTOs // Или HealthTrack.Models.DTOs, если создадите папку DTOs
{
    public class WorkoutPlanCreateModel
    {
        [Required(ErrorMessage = "Plan name is required.")] // Пример валидации: поле обязательное
        [StringLength(100, ErrorMessage = "Plan name cannot be longer than 100 characters.")] // Ограничение длины
        public string Name { get; set; }

        [Required(ErrorMessage = "Date is required.")]
        [DataType(DataType.Date)] // Указываем, что это дата (без времени)
        public DateTime Date { get; set; }

        // Добавьте сюда другие поля, если они нужны при создании плана
        // Например: public string Description { get; set; } 
    }
}