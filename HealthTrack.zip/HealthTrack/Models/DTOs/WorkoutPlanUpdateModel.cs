﻿using System;
using System.ComponentModel.DataAnnotations;

namespace HealthTrack.Models.DTOs // Или HealthTrack.Models.DTOs
{
    public class WorkoutPlanUpdateModel
    {
        // Id обычно передается в URL (api/workoutplans/{id}), поэтому его можно не включать в тело запроса.
        // Если он все же нужен в теле, раскомментируйте:
        [Required]
        public string Id { get; set; }

        [Required(ErrorMessage = "Plan name is required.")]
        [StringLength(100, ErrorMessage = "Plan name cannot be longer than 100 characters.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Date is required.")]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        // Другие поля, которые можно обновлять...
        // public string Description { get; set; }
    }
}