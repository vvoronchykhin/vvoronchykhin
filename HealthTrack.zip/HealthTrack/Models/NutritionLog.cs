﻿using System;

namespace HealthTrack.Models
{
    public class NutritionLog
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public DateTime Date { get; set; }
        public int Calories { get; set; }
        public decimal Protein { get; set; }
        public decimal Fats { get; set; }
        public decimal Carbs { get; set; }
    }
}