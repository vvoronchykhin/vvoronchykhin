﻿// Поместите этот код в wwwroot/js/site.js

/**
 * Вспомогательная функция для выполнения fetch запросов с добавлением JWT токена авторизации.
 * @param {string} url - URL эндпоинта API или Action контроллера.
 * @param {object} options - Опции для fetch (method, body, etc.). Заголовки будут добавлены автоматически.
 * @returns {Promise<Response>} - Промис с объектом Response от fetch.
 */
async function fetchWithAuth(url, options = {}) {
    const token = localStorage.getItem('authToken');

    const headers = new Headers(options.headers || {});
    headers.set('Content-Type', headers.get('Content-Type') || 'application/json');

    if (token) {
        headers.set('Authorization', `Bearer ${token}`);
    }

    const fetchOptions = { ...options, headers: headers };

    try {
        const response = await fetch(url, fetchOptions);
        if (response.status === 401) {
            console.error('Unauthorized request to:', url);
            localStorage.removeItem('authToken');
            if (window.location.pathname.toLowerCase() !== '/login') {
                window.location.href = '/Login?returnUrl=' + encodeURIComponent(window.location.pathname + window.location.search);
            }
            return response;
        }
        return response;
    } catch (error) {
        console.error('Network error during fetchWithAuth:', error);
        throw error;
    }
}


// --- Логика, выполняемая после загрузки DOM ---
document.addEventListener('DOMContentLoaded', function () {

    // --- Обработка формы входа ---
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const usernameInput = loginForm.querySelector('input[name="Username"]');
            const passwordInput = loginForm.querySelector('input[name="Password"]');
            const messageDiv = document.getElementById('loginMessage');
            if (messageDiv) messageDiv.textContent = '';

            if (!usernameInput || !passwordInput) {
                console.error("Login form inputs not found");
                if (messageDiv) messageDiv.textContent = 'Form error.';
                return;
            }

            const loginData = {
                username: usernameInput.value,
                password: passwordInput.value
            };

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(loginData),
                });

                if (response.ok) {
                    const result = await response.json();
                    if (result.token) {
                        localStorage.setItem('authToken', result.token);
                        console.log('Login successful');
                        updateLoginStatusUI(); // <-- Обновляем меню СРАЗУ после логина
                        const urlParams = new URLSearchParams(window.location.search);
                        const returnUrl = urlParams.get('returnUrl');
                        window.location.href = returnUrl || '/';
                    } else {
                        console.error('Login successful, but no token received.');
                        if (messageDiv) messageDiv.textContent = 'Server response error.';
                    }
                } else {
                    let errorMsg = 'Login failed. Check credentials.';
                    if (response.status === 401) {
                        errorMsg = 'Incorrect username or password.';
                    } else {
                        try {
                            const errorBody = await response.text();
                            if (errorBody) { errorMsg += ` (${errorBody})`; }
                        } catch { }
                    }
                    if (messageDiv) messageDiv.textContent = errorMsg;
                    console.error('Login failed:', response.status, response.statusText);
                }
            } catch (error) {
                console.error('Error during login request:', error);
                if (messageDiv) messageDiv.textContent = 'A network error occurred during login.';
            }
        });
    }

    // --- Обработка формы регистрации ---
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const usernameInput = registerForm.querySelector('input[name="Username"]');
            const emailInput = registerForm.querySelector('input[name="Email"]');
            const passwordInput = registerForm.querySelector('input[name="Password"]');
            const messageDiv = document.getElementById('registerMessage');
            if (messageDiv) messageDiv.textContent = '';

            if (!usernameInput || !emailInput || !passwordInput) {
                console.error("Register form inputs not found");
                if (messageDiv) messageDiv.textContent = 'Form error.';
                return;
            }

            const registerData = {
                username: usernameInput.value,
                email: emailInput.value,
                password: passwordInput.value
            };

            try {
                const response = await fetch('/api/auth/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(registerData),
                });

                if (response.ok) {
                    console.log('Registration successful');
                    if (messageDiv) messageDiv.textContent = 'Registration successful! Redirecting to login...';
                    setTimeout(() => window.location.href = '/Login', 2000);
                } else {
                    let errorText = 'Registration failed.';
                    try {
                        const errorData = await response.json();
                        if (errorData && Array.isArray(errorData)) {
                            errorText += ' ' + errorData.map(e => e.description || e.code).join(' ');
                        } else if (errorData && errorData.title) {
                            errorText += ' ' + errorData.title;
                        } else {
                            const rawError = await response.text();
                            if (rawError) { errorText += ` (${rawError})`; }
                            else { errorText += ` Error code: ${response.status}`; }
                        }
                    } catch {
                        const rawError = await response.text();
                        if (rawError) { errorText += ` (${rawError})`; }
                        else { errorText += ` Error code: ${response.status}`; }
                    }
                    console.error('Registration failed:', response.status, response.statusText);
                    if (messageDiv) messageDiv.textContent = errorText;
                }
            } catch (error) {
                console.error('Error during registration request:', error);
                if (messageDiv) messageDiv.textContent = 'A network error occurred during registration.';
            }
        });
    }

    // --- Обработчик кнопки Logout (через делегирование) ---
    document.body.addEventListener('click', function (event) {
        if (event.target && event.target.id === 'logoutButton') {
            localStorage.removeItem('authToken');
            console.log('Logged out');
            updateLoginStatusUI(); // <-- Обновляем меню СРАЗУ после выхода
            window.location.href = '/Login';
        }
    });

    // --- Функция обновления UI для статуса входа/выхода ---
    function updateLoginStatusUI() {
        const token = localStorage.getItem('authToken');
        const helloUserMessage = document.getElementById('helloUserMessage');
        const adminLinkContainer = document.getElementById('adminLinkContainer');

        const showLoggedIn = !!token; // true если токен есть

        // Показываем/скрываем Login/Register или Hello/Logout
        const loggedOutLinks = document.querySelectorAll('.auth-links-logged-out');
        loggedOutLinks.forEach(el => el.style.display = showLoggedIn ? 'none' : 'block');

        const loggedInLinks = document.querySelectorAll('.auth-links-logged-in');
        loggedInLinks.forEach(el => el.style.display = showLoggedIn ? 'block' : 'none');

        // Показываем/скрываем админскую ссылку и имя пользователя, если залогинен
        if (showLoggedIn) {
            if (adminLinkContainer) adminLinkContainer.style.display = 'none'; // Скрыть по умолчанию
            try {
                const payloadBase64 = token.split('.')[1];
                const payloadJson = atob(payloadBase64.replace(/-/g, '+').replace(/_/g, '/'));
                const payload = JSON.parse(payloadJson);

                const rolesClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role";
                let isAdmin = false;
                if (payload[rolesClaim]) {
                    if (Array.isArray(payload[rolesClaim])) { isAdmin = payload[rolesClaim].includes("Admin"); }
                    else { isAdmin = payload[rolesClaim] === "Admin"; }
                }
                if (isAdmin && adminLinkContainer) { adminLinkContainer.style.display = 'block'; }

                const nameClaim = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name";
                const helloUserMessage = document.getElementById('helloUserMessage');
                if (helloUserMessage && payload[nameClaim]) { helloUserMessage.textContent = `Hello ${payload[nameClaim]}!`; }
                else if (helloUserMessage && payload.sub) { helloUserMessage.textContent = `Hello ${payload.sub}!`; }
                else if (helloUserMessage) { helloUserMessage.textContent = `Hello!`; }

            } catch (e) {
                console.error("Error decoding token for UI update:", e);
                if (adminLinkContainer) adminLinkContainer.style.display = 'none';
                const helloUserMessage = document.getElementById('helloUserMessage');
                if (helloUserMessage) helloUserMessage.textContent = `Hello!`;
            }
        } else {
            if (adminLinkContainer) adminLinkContainer.style.display = 'none';
        }
    }

    // Вызываем функцию обновления UI сразу при загрузке скрипта
    updateLoginStatusUI();

}); // Конец 'DOMContentLoaded'