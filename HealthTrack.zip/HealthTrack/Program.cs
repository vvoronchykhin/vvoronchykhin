﻿using HealthTrack.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

builder.Services.AddIdentity<IdentityUser, IdentityRole>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("RequireAdminRole", policy => policy.RequireRole("Admin"));
});

builder.Services.AddControllersWithViews(); // If you are using MVC Controllers
builder.Services.AddRazorPages();

// Добавляем сервисы аутентификации и авторизации ДО вызова builder.Build()
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
        };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Home/Error"); // Or "/Error" if it's a Razor Page app
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication(); // Конфигурация middleware аутентификации
app.UseAuthorization(); // Конфигурация middleware авторизации

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();


// Вставьте ЭТОТ ИСПРАВЛЕННЫЙ БЛОК вместо старого using(...) в Program.cs

using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try // Добавим try-catch для отладки
    {
        Console.WriteLine("Entering Program.cs scope for seeding/reset..."); // <-- Добавлено для проверки входа в блок

        var context = services.GetRequiredService<ApplicationDbContext>();
        context.Database.Migrate();
        Console.WriteLine("Database migration check complete.");

        var userManager = services.GetRequiredService<UserManager<IdentityUser>>();
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        Console.WriteLine("UserManager and RoleManager obtained.");

        // --- Создание роли Admin (если ее нет) ---
        if (!await roleManager.RoleExistsAsync("Admin"))
        {
            Console.WriteLine("Admin role does not exist. Creating...");
            var roleResult = await roleManager.CreateAsync(new IdentityRole("Admin"));
            if (roleResult.Succeeded) { Console.WriteLine("Admin role created successfully."); }
            else { Console.WriteLine($"Error creating Admin role: {string.Join(", ", roleResult.Errors.Select(e => e.Description))}"); }
        }
        else
        {
            Console.WriteLine("Admin role already exists.");
        }

        // --- Проверка/Создание пользователя Admin (если его нет) ---
        var adminUser = await userManager.FindByEmailAsync("admin@example.com") ?? await userManager.FindByNameAsync("admin");

        if (adminUser == null)
        {
            Console.WriteLine("Admin user not found by email or username. Creating...");
            adminUser = new IdentityUser { UserName = "admin", Email = "admin@example.com" };
            // Используем пароль "AdminPassword123!" при создании
            var createResult = await userManager.CreateAsync(adminUser, "AdminPassword123!");
            if (createResult.Succeeded)
            {
                Console.WriteLine("Admin user created successfully.");
                var addToRoleResult = await userManager.AddToRoleAsync(adminUser, "Admin");
                if (addToRoleResult.Succeeded) { Console.WriteLine("Admin user added to Admin role successfully."); }
                else { Console.WriteLine($"Error adding Admin user to Admin role: {string.Join(", ", addToRoleResult.Errors.Select(e => e.Description))}"); }
            }
            else
            {
                Console.WriteLine($"Error creating admin user: {string.Join(", ", createResult.Errors.Select(e => e.Description))}");
            }
        }
        else
        {
            Console.WriteLine("Admin user already exists (found by email or username).");
            if (!await userManager.IsInRoleAsync(adminUser, "Admin"))
            {
                Console.WriteLine("Existing admin user is NOT in Admin role. Adding...");
                var addToRoleResult = await userManager.AddToRoleAsync(adminUser, "Admin");
                if (addToRoleResult.Succeeded) { Console.WriteLine("Existing admin user added to Admin role successfully."); }
                else { Console.WriteLine($"Error adding existing Admin user to Admin role: {string.Join(", ", addToRoleResult.Errors.Select(e => e.Description))}"); }
            }
        }

        Console.WriteLine("Finished Program.cs scope for seeding/reset."); // <-- Добавлено для проверки выхода из блока

    }
    catch (Exception ex)
    {
        Console.WriteLine($"!!!!!!!! An error occurred during seeding/password reset: {ex.ToString()} !!!!!!!!"); // Выводим полный стек ошибки
    }
} // Конец using scope

app.Run();