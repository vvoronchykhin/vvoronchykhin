﻿using Microsoft.AspNetCore.Mvc;
using HealthTrack.Data;
using HealthTrack.Models; // Убедитесь, что здесь есть WorkoutPlan
using HealthTrack.Models.DTOs; // <-- Добавьте using для DTO, если создали папку DTOs
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity; // <-- Добавьте для UserManager
using System.Linq;                 // <-- Добавьте для .Where(), .Select(), .ToListAsync()
using System.Security.Claims;    // <-- Добавьте для GetUserId (альтернативный способ)

namespace HealthTrack.Controllers
{
    [Route("api/workoutplans")] // Базовый маршрут для API
    [ApiController]             // Указываем, что это API контроллер
    [Authorize]                 // Защищаем все методы - нужен валидный JWT токен
    public class WorkoutPlanController : ControllerBase // <-- Наследуемся от ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<IdentityUser> _userManager; // Добавляем UserManager

        public WorkoutPlanController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager; // Сохраняем UserManager
        }

        // GET: api/workoutplans 
        // Получение списка планов тренировок для ТЕКУЩЕГО пользователя
        [HttpGet]
        public async Task<ActionResult<IEnumerable<object>>> GetWorkoutPlans()
        {
            // Получаем ID текущего пользователя из токена
            // var userId = _userManager.GetUserId(User); 
            // ИЛИ более надежный способ из Claims:
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (string.IsNullOrEmpty(userId))
            {
                // Это не должно произойти при наличии [Authorize], но проверяем
                return Unauthorized("User ID not found in token.");
            }

            var plans = await _context.WorkoutPlans
                                      .Where(wp => wp.UserId == userId) // <-- ВАЖНО: Фильтр по UserId!
                                      .OrderByDescending(wp => wp.Date)
                                      .Select(wp => new { // Возвращаем анонимный объект или DTO
                                          wp.Id,
                                          wp.Name,
                                          Date = wp.Date.ToShortDateString()
                                      })
                                      .ToListAsync();

            return Ok(plans); // Возвращаем JSON со статусом 200 OK
        }

        // GET: api/workoutplans/{id}
        // Получение деталей одного плана ТЕКУЩЕГО пользователя
        [HttpGet("{id}")]
        public async Task<ActionResult<WorkoutPlan>> GetWorkoutPlan(Guid id) // Бывший Details
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            var workoutPlan = await _context.WorkoutPlans
                                            // Можно добавить .Include() для связанных данных, если нужно
                                            .FirstOrDefaultAsync(wp => wp.Id == id && wp.UserId == userId); // Ищем по ID и UserId

            if (workoutPlan == null)
            {
                return NotFound(); // 404 Not Found (не найден или принадлежит другому пользователю)
            }

            return Ok(workoutPlan); // Возвращаем JSON со статусом 200 OK
        }

        // POST: api/workoutplans
        // Создание нового плана для ТЕКУЩЕГО пользователя
        [HttpPost]
        // [ValidateAntiForgeryToken] // <-- УБРАТЬ
        public async Task<ActionResult<WorkoutPlan>> CreateWorkoutPlan([FromBody] WorkoutPlanCreateModel model) // Принимаем DTO из тела запроса
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            if (!ModelState.IsValid) // Проверка валидации DTO (атрибуты [Required] и т.д.)
            {
                return BadRequest(ModelState); // 400 Bad Request с ошибками валидации
            }

            var workoutPlan = new WorkoutPlan
            {
                // Id обычно генерируется БД (если Guid, можно Guid.NewGuid())
                UserId = userId, // <-- Присваиваем ID текущего пользователя
                Name = model.Name,
                Date = model.Date
                // Другие поля из model, если они есть...
            };

            _context.WorkoutPlans.Add(workoutPlan);
            await _context.SaveChangesAsync();

            // Возвращаем статус 201 Created, ссылку на созданный ресурс и сам ресурс
            return CreatedAtAction(nameof(GetWorkoutPlan), new { id = workoutPlan.Id }, workoutPlan);
        }

        // PUT: api/workoutplans/{id}
        // Обновление существующего плана ТЕКУЩЕГО пользователя
        [HttpPut("{id}")]
        // [ValidateAntiForgeryToken] // <-- УБРАТЬ
        public async Task<IActionResult> UpdateWorkoutPlan(Guid id, [FromBody] WorkoutPlanUpdateModel model) // Принимаем DTO
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Ищем существующий план по ID и UserId
            var existingPlan = await _context.WorkoutPlans.FirstOrDefaultAsync(wp => wp.Id == id && wp.UserId == userId);

            if (existingPlan == null)
            {
                return NotFound(); // 404 Not Found (не найден или принадлежит другому)
            }

            // Обновляем поля
            existingPlan.Name = model.Name;
            existingPlan.Date = model.Date;
            // ... обновить другие поля из model ...

            // Помечаем сущность как измененную (не обязательно, EF Core часто отслеживает сам)
            // _context.Entry(existingPlan).State = EntityState.Modified; 

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // Обработка конфликта параллельного доступа (если кто-то удалил/изменил запись одновременно)
                if (!WorkoutPlanExists(id, userId)) // Проверяем существование с учетом UserId
                {
                    return NotFound();
                }
                else { throw; }
            }

            return NoContent(); // Статус 204 No Content - успешное обновление без возврата тела
        }

        // DELETE: api/workoutplans/{id}
        // Удаление плана ТЕКУЩЕГО пользователя
        [HttpDelete("{id}")]
        // [ValidateAntiForgeryToken] // <-- УБРАТЬ
        // [ActionName("Delete")] // <-- УБРАТЬ
        public async Task<IActionResult> DeleteWorkoutPlan(Guid id) // Было DeleteConfirmed
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            // Ищем план по ID и UserId
            var workoutPlan = await _context.WorkoutPlans.FirstOrDefaultAsync(wp => wp.Id == id && wp.UserId == userId);
            if (workoutPlan == null)
            {
                return NotFound(); // 404 Not Found (не найден или принадлежит другому)
            }

            _context.WorkoutPlans.Remove(workoutPlan);
            await _context.SaveChangesAsync();

            return NoContent(); // Статус 204 No Content - успешное удаление
        }


        // Вспомогательный метод проверки существования (можно добавить UserId)
        private bool WorkoutPlanExists(Guid id, string userId)
        {
            return _context.WorkoutPlans.Any(e => e.Id == id && e.UserId == userId);
        }
    }
}