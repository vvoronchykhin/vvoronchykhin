﻿using Microsoft.AspNetCore.Mvc;
using HealthTrack.Data;
using HealthTrack.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;

namespace HealthTrack.Controllers
{
    [Authorize]
    public class NutritionLogController : Controller
    {
        private readonly ApplicationDbContext _context;

        public NutritionLogController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: NutritionLogs
        public async Task<IActionResult> Index()
        {
            return View(await _context.NutritionLogs.ToListAsync());
        }

        // GET: NutritionLogs/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var nutritionLog = await _context.NutritionLogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (nutritionLog == null)
            {
                return NotFound();
            }

            return View(nutritionLog);
        }

        // GET: NutritionLogs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: NutritionLogs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(NutritionLog nutritionLog)
        {
            if (ModelState.IsValid)
            {
                _context.NutritionLogs.Add(nutritionLog);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(nutritionLog);
        }

        // GET: NutritionLogs/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var nutritionLog = await _context.NutritionLogs.FindAsync(id);
            if (nutritionLog == null)
            {
                return NotFound();
            }
            return View(nutritionLog);
        }

        // POST: NutritionLogs/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,UserId,Date,Calories,Protein,Fats,Carbs")] NutritionLog nutritionLog)
        {
            if (id != nutritionLog.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(nutritionLog);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!NutritionLogExists(nutritionLog.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(nutritionLog);
        }

        // GET: NutritionLogs/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var nutritionLog = await _context.NutritionLogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (nutritionLog == null)
            {
                return NotFound();
            }

            return View(nutritionLog);
        }

        // POST: NutritionLogs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var nutritionLog = await _context.NutritionLogs.FindAsync(id);
            _context.NutritionLogs.Remove(nutritionLog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool NutritionLogExists(Guid id)
        {
            return _context.NutritionLogs.Any(e => e.Id == id);
        }
    }
}