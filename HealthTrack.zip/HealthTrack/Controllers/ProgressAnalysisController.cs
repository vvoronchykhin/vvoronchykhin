﻿using Microsoft.AspNetCore.Mvc;
using HealthTrack.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;

namespace HealthTrack.Controllers
{
    [Authorize]
    public class ProgressAnalysisController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProgressAnalysisController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Progress Analysis
        public IActionResult Index()
        {
            return View(); // You'll need to create an Index.cshtml view
        }

        // GET: WeeklyReport
        public async Task<IActionResult> WeeklyReport()
        {
            // Logic to fetch data for the weekly report
            // Example:
            var userId = Guid.Parse(User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")?.Value);
            var today = DateTime.Now.Date;
            var startOfWeek = today.AddDays(DayOfWeek.Monday - today.DayOfWeek);
            var endOfWeek = startOfWeek.AddDays(6);

            var workoutLogs = await _context.WorkoutLogs
                .Where(log => log.Date >= startOfWeek && log.Date <= endOfWeek)
                .ToListAsync();

            var weightLogs = await _context.WeightLogs
                .Where(log => log.UserId == userId && log.Date >= startOfWeek && log.Date <= endOfWeek)
                .ToListAsync();

            var nutritionLogs = await _context.NutritionLogs
                .Where(log => log.UserId == userId && log.Date >= startOfWeek && log.Date <= endOfWeek)
                .ToListAsync();

            ViewBag.WorkoutLogs = workoutLogs;
            ViewBag.WeightLogs = weightLogs;
            ViewBag.NutritionLogs = nutritionLogs;

            return View(); // You'll need to create a WeeklyReport.cshtml view
        }

        // GET: MonthlyReport
        public async Task<IActionResult> MonthlyReport()
        {
            // Logic to fetch data for the monthly report (similar to WeeklyReport, but for a month)

            var userId = Guid.Parse(User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier")?.Value);
            var today = DateTime.Now.Date;
            var startOfMonth = new DateTime(today.Year, today.Month, 1);
            var endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);

            var workoutLogs = await _context.WorkoutLogs
                .Where(log => log.Date >= startOfMonth && log.Date <= endOfMonth)
                .ToListAsync();

            var weightLogs = await _context.WeightLogs
                .Where(log => log.UserId == userId && log.Date >= startOfMonth && log.Date <= endOfMonth)
                .ToListAsync();

            var nutritionLogs = await _context.NutritionLogs
                .Where(log => log.UserId == userId && log.Date >= startOfMonth && log.Date <= endOfMonth)
                .ToListAsync();

            ViewBag.WorkoutLogs = workoutLogs;
            ViewBag.WeightLogs = weightLogs;
            ViewBag.NutritionLogs = nutritionLogs;

            return View(); // You'll need to create a MonthlyReport.cshtml view
        }

        // You can add more actions for different types of analysis
    }
}