﻿using Microsoft.AspNetCore.Mvc;
using HealthTrack.Data;
using HealthTrack.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;

namespace HealthTrack.Controllers
{
    [Authorize]
    public class WorkoutLogController : Controller
    {
        private readonly ApplicationDbContext _context;

        public WorkoutLogController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Workout Logs
        public async Task<IActionResult> Index()
        {
            return View(await _context.WorkoutLogs.ToListAsync());
        }

        // GET: Workout Logs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Workout Logs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(WorkoutLog workoutLog)
        {
            if (ModelState.IsValid)
            {
                _context.WorkoutLogs.Add(workoutLog);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(workoutLog);
        }

        // GET: WorkoutLogs/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workoutLog = await _context.WorkoutLogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (workoutLog == null)
            {
                return NotFound();
            }

            return View(workoutLog);
        }

        // GET: WorkoutLogs/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workoutLog = await _context.WorkoutLogs.FindAsync(id);
            if (workoutLog == null)
            {
                return NotFound();
            }
            return View(workoutLog);
        }

        // POST: WorkoutLogs/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,WorkoutPlanId,Date,Duration")] WorkoutLog workoutLog)
        {
            if (id != workoutLog.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(workoutLog);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WorkoutLogExists(workoutLog.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(workoutLog);
        }

        // GET: WorkoutLogs/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workoutLog = await _context.WorkoutLogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (workoutLog == null)
            {
                return NotFound();
            }

            return View(workoutLog);
        }

        // POST: WorkoutLogs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var workoutLog = await _context.WorkoutLogs.FindAsync(id);
            _context.WorkoutLogs.Remove(workoutLog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool WorkoutLogExists(Guid id)
        {
            return _context.WorkoutLogs.Any(e => e.Id == id);
        }
    }
}