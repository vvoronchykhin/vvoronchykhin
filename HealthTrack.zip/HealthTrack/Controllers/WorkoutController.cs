﻿using Microsoft.AspNetCore.Mvc;
using HealthTrack.Data;
using HealthTrack.Models;
// using HealthTrack.Models.DTOs; // <-- УДАЛИТЕ или ИСПРАВЬТЕ, если ошибка CS0234 еще есть
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;    // <-- Убедитесь, что этот using добавлен

namespace HealthTrack.Controllers
{
    [Route("api/workouts")] // Маршрут API
    [ApiController]
    [Authorize] // Защита
    public class WorkoutController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public WorkoutController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/workouts/plans
        [HttpGet("plans")]
        public async Task<ActionResult<IEnumerable<WorkoutPlan>>> GetWorkoutPlans()
        {
            // --- ИСПРАВЛЕНО: Получаем UserId как string ---
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized("User ID not found in token.");
            }

            // --- Сравнение string со string (при условии, что WorkoutPlan.UserId - string) ---
            var plans = await _context.WorkoutPlans
                                      .Where(p => p.UserId == userId)
                                      .ToListAsync();
            return Ok(plans);
        }

        // GET: api/workouts/plans/{id}
        [HttpGet("plans/{id}")]
        public async Task<ActionResult<WorkoutPlan>> GetWorkoutPlan(Guid id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            // --- ИСПРАВЛЕНО: Сравнение string со string ---
            var workoutPlan = await _context.WorkoutPlans
                                            .FirstOrDefaultAsync(wp => wp.Id == id && wp.UserId == userId);

            if (workoutPlan == null)
            {
                return NotFound();
            }
            return Ok(workoutPlan);
        }

        // POST: api/workouts/plans
        // Примечание: Этот метод принимает весь WorkoutPlan. Лучше использовать DTO (WorkoutPlanCreateModel).
        [HttpPost("plans")]
        public async Task<ActionResult<WorkoutPlan>> CreateWorkoutPlan([FromBody] WorkoutPlan workoutPlan)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            if (!ModelState.IsValid) { return BadRequest(ModelState); }

            // --- ИСПРАВЛЕНО: Присваиваем string UserId ---
            workoutPlan.UserId = userId;
            workoutPlan.Id = Guid.NewGuid();

            _context.WorkoutPlans.Add(workoutPlan);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetWorkoutPlan), new { id = workoutPlan.Id }, workoutPlan);
        }

        // PUT: api/workouts/plans/{id}
        // Примечание: Этот метод принимает весь WorkoutPlan. Лучше использовать DTO (WorkoutPlanUpdateModel).
        [HttpPut("plans/{id}")]
        public async Task<IActionResult> UpdateWorkoutPlan(Guid id, [FromBody] WorkoutPlan workoutPlan)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            if (id != workoutPlan.Id) { return BadRequest("ID mismatch."); }

            // Проверка принадлежности плана пользователю перед обновлением
            var existingPlan = await _context.WorkoutPlans.AsNoTracking()
                                    .FirstOrDefaultAsync(p => p.Id == id && p.UserId == userId); // <-- Исправлено сравнение
            if (existingPlan == null)
            {
                // Нельзя обновлять чужой план или несуществующий
                return Forbid(); // Или NotFound()
            }
            // Устанавливаем UserId из токена, чтобы его нельзя было подменить в запросе
            workoutPlan.UserId = userId;

            if (!ModelState.IsValid) { return BadRequest(ModelState); }

            _context.Entry(workoutPlan).State = EntityState.Modified;

            try { await _context.SaveChangesAsync(); }
            catch (DbUpdateConcurrencyException)
            {
                // --- ИСПРАВЛЕНО: Передаем string userId ---
                if (!WorkoutPlanExists(id, userId)) { return NotFound(); } else { throw; }
            }
            return NoContent();
        }

        // DELETE: api/workouts/plans/{id}
        [HttpDelete("plans/{id}")]
        public async Task<IActionResult> DeleteWorkoutPlan(Guid id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            // --- ИСПРАВЛЕНО: Сравнение string со string ---
            var workoutPlan = await _context.WorkoutPlans.FirstOrDefaultAsync(wp => wp.Id == id && wp.UserId == userId);
            if (workoutPlan == null) { return NotFound(); }

            _context.WorkoutPlans.Remove(workoutPlan);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Методы для WorkoutPlanExercises: Тоже исправляем получение и сравнение UserId

        // GET: api/workouts/plans/{id}/exercises
        [HttpGet("plans/{id}/exercises")]
        public async Task<ActionResult<IEnumerable<WorkoutPlanExercise>>> GetWorkoutPlanExercises(Guid id)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            // --- ИСПРАВЛЕНО: Проверка владельца плана ---
            var planExistsForUser = await _context.WorkoutPlans.AnyAsync(p => p.Id == id && p.UserId == userId);
            if (!planExistsForUser) { return NotFound("Workout plan not found for this user."); }

            return await _context.WorkoutPlanExercises
                                 .Where(e => e.WorkoutPlanId == id)
                                 .ToListAsync();
        }

        // POST: api/workouts/plans/{id}/exercises
        [HttpPost("plans/{id}/exercises")]
        public async Task<ActionResult<WorkoutPlanExercise>> AddExerciseToWorkoutPlan(Guid id, [FromBody] WorkoutPlanExercise workoutPlanExercise)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId)) return Unauthorized("User ID not found in token.");

            // --- ИСПРАВЛЕНО: Проверка владельца плана ---
            var planExistsForUser = await _context.WorkoutPlans.AnyAsync(p => p.Id == id && p.UserId == userId);
            if (!planExistsForUser) { return NotFound("Workout plan not found for this user."); }

            if (!ModelState.IsValid) { return BadRequest(ModelState); }

            workoutPlanExercise.WorkoutPlanId = id;
            // workoutPlanExercise.Id = Guid.NewGuid(); // Если нужно

            _context.WorkoutPlanExercises.Add(workoutPlanExercise);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetWorkoutPlanExercises), new { id = id }, workoutPlanExercise);
        }

        // --- ИСПРАВЛЕНО: Принимает string userId ---
        private bool WorkoutPlanExists(Guid id, string userId)
        {
            // --- ИСПРАВЛЕНО: Сравнение string со string ---
            return _context.WorkoutPlans.Any(e => e.Id == id && e.UserId == userId);
        }
    }
}