﻿using Microsoft.AspNetCore.Mvc;
using HealthTrack.Data;
using HealthTrack.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;

namespace HealthTrack.Controllers
{
    [Authorize]
    public class WeightLogController : Controller
    {
        private readonly ApplicationDbContext _context;

        public WeightLogController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: WeightLogs
        public async Task<IActionResult> Index()
        {
            return View(await _context.WeightLogs.ToListAsync());
        }

        // GET: WeightLogs/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var weightLog = await _context.WeightLogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (weightLog == null)
            {
                return NotFound();
            }

            return View(weightLog);
        }

        // GET: WeightLogs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: WeightLogs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(WeightLog weightLog)
        {
            if (ModelState.IsValid)
            {
                _context.WeightLogs.Add(weightLog);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(weightLog);
        }

        // GET: WeightLogs/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var weightLog = await _context.WeightLogs.FindAsync(id);
            if (weightLog == null)
            {
                return NotFound();
            }
            return View(weightLog);
        }

        // POST: WeightLogs/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Id,UserId,Date,Weight")] WeightLog weightLog)
        {
            if (id != weightLog.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(weightLog);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WeightLogExists(weightLog.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(weightLog);
        }

        // GET: WeightLogs/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var weightLog = await _context.WeightLogs
                .FirstOrDefaultAsync(m => m.Id == id);
            if (weightLog == null)
            {
                return NotFound();
            }

            return View(weightLog);
        }

        // POST: WeightLogs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var weightLog = await _context.WeightLogs.FindAsync(id);
            _context.WeightLogs.Remove(weightLog);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool WeightLogExists(Guid id)
        {
            return _context.WeightLogs.Any(e => e.Id == id);
        }
    }
}