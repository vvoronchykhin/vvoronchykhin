using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HealthTrack.Pages
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
