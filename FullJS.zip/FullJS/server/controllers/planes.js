const fs = require("fs");
const path = require("path");

const assetsDir = path.join(__dirname, "assets");
if (!fs.existsSync(assetsDir)) {
  fs.mkdirSync(assetsDir);
}

const Plane = require("../../models/planes");

const getPlanes = async (req, res) => {
  try {
    const planes = await Plane.find();
    res.status(200).json(planes);
  } catch (err) {
    console.error("Error fetching planes:", err);
    res.status(500).json({ message: "Failed to fetch planes." });
  }
};

const createPlane = async (req, res) => {
  try {
    const { name, price, description, capacity } = req.body;
    const planeImageUrl = `http://localhost:${process.env.PORT || 8000}/static/${req.file.filename}`;

    const plane = await Plane.create({
      name,
      price,
      description,
      capacity,
      planeImage: planeImageUrl,
    });

    res.status(201).json(plane);
  } catch (err) {
    console.error("Error creating plane:", err);
    res.status(500).json({ message: "Failed to create plane." });
  }
};

const getPlaneById = async (req, res) => {
  try {
    const plane = await Plane.findById(req.params.id);
    if (!plane) {
      return res.status(404).json({ message: "Plane not found" });
    }
    res.status(200).json(plane);
  } catch (err) {
    console.error("Error fetching plane:", err);
    res.status(500).json({ message: "Failed to fetch plane." });
  }
};

const deletePlane = async (req, res) => {
  try {
    const { id } = req.params;
    const plane = await Plane.findByIdAndDelete(id);
    if (!plane) {
      return res.status(404).json({ message: "Plane not found" });
    }
    res.status(200).json({ message: "Plane deleted successfully." });
  } catch (err) {
    console.error("Error deleting plane:", err);
    res.status(500).json({ message: "Failed to delete plane." });
  }
};


const updatePlane = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, price, description, capacity } = req.body;

    // If a new image is uploaded, update the image URL
    let planeImageUrl;
    if (req.file) {
      planeImageUrl = `http://localhost:${process.env.PORT || 8000}/static/${req.file.filename}`;
    }

    const updatedPlane = await Plane.findByIdAndUpdate(
      id,
      {
        name,
        price,
        description,
        capacity,
        ...(planeImageUrl && { planeImage: planeImageUrl }), // Only update image if provided
      },
      { new: true } 
    );

    if (!updatedPlane) {
      return res.status(404).json({ message: "Plane not found" });
    }

    res.status(200).json(updatedPlane);
  } catch (err) {
    console.error("Error updating plane:", err);
    res.status(500).json({ message: "Failed to update plane." });
  }
};

module.exports = { getPlanes, createPlane, getPlaneById, deletePlane, updatePlane };