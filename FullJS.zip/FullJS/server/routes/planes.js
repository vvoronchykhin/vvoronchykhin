const express = require("express");
const router = express.Router();
const multer = require("multer");

// Set up storage (adjust destination and filename as needed)
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "assets/"); // folder where images are saved
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage: storage });

const { getPlanes, createPlane, getPlaneById, deletePlane, updatePlane } = require("../controllers/planes");

// Define routes
router.get("/", getPlanes);
router.get("/:id", getPlaneById);
router.post("/", upload.single("planeImage"), createPlane);
router.delete("/:id", deletePlane);
router.put("/:id", upload.single("planeImage"), updatePlane); 

module.exports = router;