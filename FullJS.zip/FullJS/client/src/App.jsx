import React, { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/header/header";
import HomePage from "./pages/main-page";
import { CreatePlanePage } from "./pages/create-plane-page/create-plane-page";
import { PlanePage } from "./pages/plane-page/plane-page";
import { OrderPage } from "./pages/order-page";
import { paths } from "./paths";
import { UpdatePlanePage } from "./pages/update-plane-page/update-plane-page";

//show only the header
function App() {
  const [showLanding, setShowLanding] = useState(true);

  const handleGetStarted = () => {
    setShowLanding(false);
  };

  return (
    <BrowserRouter>
      {showLanding ? (
        <Header onGetStarted={handleGetStarted} />
      ) : (
        <Routes>
          <Route path={paths.home} element={<HomePage />} />
          <Route path={`${paths.plane}/:id`} element={<PlanePage />} />
          <Route path={paths.createPlane} element={<CreatePlanePage />} />
          <Route path={paths.order} element={<OrderPage />} />
          <Route path={`/update-plane/:id`} element={<UpdatePlanePage />} /> {/* Add this */}
        </Routes>
      )}
    </BrowserRouter>
  );
}

export default App;
