import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { getPlane, fetchPlanes } from "../../store/plane/planeSlice";
import axios from "axios";
import styles from "./styles.module.css";

export const UpdatePlanePage = () => {
  const { id } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { plane, isLoading } = useSelector((state) => state.planes);

  const [name, setName] = useState("");
  const [nameError, setNameError] = useState("");
  const [price, setPrice] = useState("");
  const [priceError, setPriceError] = useState("");
  const [description, setDescription] = useState("");
  const [descError, setDescError] = useState("");
  const [capacity, setCapacity] = useState("");
  const [capacityError, setCapacityError] = useState("");
  const [planeImage, setPlaneImage] = useState(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (id) {
      dispatch(getPlane(id));
    }
  }, [dispatch, id]);

  useEffect(() => {
    if (plane) {
      setName(plane.name);
      setPrice(plane.price);
      setDescription(plane.description);
      setCapacity(plane.capacity);
    }
  }, [plane]);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const validFormats = ["image/jpeg", "image/png"];
      if (!validFormats.includes(file.type)) {
        setMessage("Invalid file type. Only JPG and PNG files are allowed.");
        setPlaneImage(null);
        return;
      }
      setPlaneImage(file);
      setMessage("");
    }
  };

  const handleUpdatePlane = async () => {
    if (!name.trim()) {
      setNameError("Name is required.");
      return;
    }
    if (!price) {
      setPriceError("Price is required.");
      return;
    }
    if (!description.trim()) {
      setDescError("Description is required.");
      return;
    }
    if (!capacity) {
      setCapacityError("Capacity is required.");
      return;
    }
    if (nameError || priceError || descError || capacityError) {
      setMessage("Please fix the errors before submitting.");
      return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("price", price);
    formData.append("description", description);
    formData.append("capacity", capacity);
    if (planeImage) {
      formData.append("planeImage", planeImage);
    }

    try {
      const response = await axios.put(`/api/planes/${id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      if (response.status === 200) {
        setMessage("Plane updated successfully!");
        dispatch(fetchPlanes()); // Refresh the list
        navigate("/");
      }
    } catch (err) {
      console.error("Error updating plane:", err);
      setMessage("Failed to update plane.");
    }
  };

  if (isLoading) return <p>Loading...</p>;

  return (
    <div className={styles.updatePlane}>
      <h1>Update Plane</h1>
      {message && <p>{message}</p>}
      <div>
        <input
          type="text"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        {nameError && <p className={styles.errorMessage}>{nameError}</p>}
      </div>
      <div>
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        {priceError && <p className={styles.errorMessage}>{priceError}</p>}
      </div>
      <div>
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        {descError && <p className={styles.errorMessage}>{descError}</p>}
      </div>
      <div>
        <input
          type="number"
          placeholder="Capacity"
          value={capacity}
          onChange={(e) => setCapacity(e.target.value)}
        />
        {capacityError && <p className={styles.errorMessage}>{capacityError}</p>}
      </div>
      <div>
        <input type="file" onChange={handleFileChange} />
      </div>
      <button onClick={handleUpdatePlane}>Update Plane</button>
    </div>
  );
};

export default UpdatePlanePage;