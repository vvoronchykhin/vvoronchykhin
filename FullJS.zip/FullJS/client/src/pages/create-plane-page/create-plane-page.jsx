import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { fetchPlanes } from "../../store/plane/planeSlice"; 
import axios from "axios";
import styles from "./styles.module.css";

export const CreatePlanePage = () => {
  const [name, setName] = useState("");
  const [nameError, setNameError] = useState("");
  const [price, setPrice] = useState("");
  const [priceError, setPriceError] = useState("");
  const [description, setDescription] = useState("");
  const [descError, setDescError] = useState("");
  const [capacity, setCapacity] = useState("");
  const [capacityError, setCapacityError] = useState("");
  const [planeImage, setPlaneImage] = useState(null);
  const [message, setMessage] = useState("");

  const dispatch = useDispatch();
  const navigate = useNavigate();

  // Now, allow all characters in the name field 
  const handleNameChange = (e) => {
    setName(e.target.value);
    setNameError("");
  };

  // Validate price input 
  const handlePriceChange = (e) => {
    const value = e.target.value;
    if (value && !/^\d*$/.test(value)) {
      setPriceError("Price can only contain numbers.");
    } else {
      setPriceError("");
    }
    setPrice(value);
  };

  // Validate description 
  const handleDescriptionChange = (e) => {
    const value = e.target.value;
    if (value.length > 400) {
      setDescError("Description cannot be more than 400 characters.");
    } else {
      setDescError("");
    }
    setDescription(value);
  };

  // Validate capacity 
  const handleCapacityChange = (e) => {
    const value = e.target.value;
    if (value !== "" && (Number(value) > 100 || Number(value) < 0)) {
      setCapacityError("Capacity must be between 0 and 100.");
    } else {
      setCapacityError("");
    }
    setCapacity(value);
  };

  // Validate file type
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const validFormats = ["image/jpeg", "image/png"];
      if (!validFormats.includes(file.type)) {
        setMessage("Invalid file type. Only JPG and PNG files are allowed.");
        setPlaneImage(null);
        return;
      }
      setPlaneImage(file);
      setMessage("");
    }
  };

  const handleCreatePlane = async () => {
    if (!name.trim()) {
      setNameError("Name is required.");
      return;
    }
    if (!price) {
      setPriceError("Price is required.");
      return;
    }
    if (!description.trim()) {
      setDescError("Description is required.");
      return;
    }
    if (!capacity) {
      setCapacityError("Capacity is required.");
      return;
    }
    if (!planeImage) {
      setMessage("Please upload an image in JPG or PNG format.");
      return;
    }
    if (nameError || priceError || descError || capacityError) {
      setMessage("Please fix the errors before submitting.");
      return;
    }

    const formData = new FormData();
    formData.append("name", name);
    formData.append("price", price);
    formData.append("description", description);
    formData.append("capacity", capacity);
    formData.append("planeImage", planeImage);

    try {
      const response = await axios.post("/api/planes", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      if (response.status === 201) {
        setMessage("Plane created successfully!");
        dispatch(fetchPlanes()); 
        setName("");
        setPrice("");
        setDescription("");
        setCapacity("");
        setPlaneImage(null);
      }
    } catch (err) {
      console.error("Error creating plane:", err);
      setMessage("Failed to create plane.");
    }
  };

  return (
    <div className={styles.createPlane}>
      {/* Back button as a cross in a circle positioned at top right */}
      <div className={styles.backButton} onClick={() => navigate(-1)}>
        &times;
      </div>
      <div className={styles.form}>
        <h1 className={styles.title}>Create a Plane</h1>
        {message && <p>{message}</p>}
        <div>
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={handleNameChange}
            className={styles.inputField}
          />
          {nameError && <p className={styles.errorMessage}>{nameError}</p>}
        </div>
        <div>
          <input
            type="number"
            placeholder="Price"
            value={price}
            onChange={handlePriceChange}
            className={styles.inputField}
          />
          {priceError && <p className={styles.errorMessage}>{priceError}</p>}
        </div>
        <div>
          <textarea
            placeholder="Description"
            value={description}
            onChange={handleDescriptionChange}
            className={styles.inputField}
          />
          <p>{400 - description.length} characters left.</p>
          {descError && <p className={styles.errorMessage}>{descError}</p>}
        </div>
        <div>
          <input
            type="number"
            placeholder="Capacity"
            value={capacity}
            onChange={handleCapacityChange}
            className={styles.inputField}
          />
          {capacityError && (
            <p className={styles.errorMessage}>{capacityError}</p>
          )}
        </div>
        <div>
          <input
            type="file"
            onChange={handleFileChange}
            className={styles.inputField}
          />
        </div>
        <button onClick={handleCreatePlane} className={styles.button}>
          Create Plane
        </button>
      </div>
    </div>
  );
};

export default CreatePlanePage;