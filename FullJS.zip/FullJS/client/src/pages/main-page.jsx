import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchPlanes } from "../store/plane/planeSlice";
import PlaneItem from "../components/plane-item/plane-item.jsx";
import { Link } from "react-router-dom";
import { paths } from "../paths";
import styles from "./main-page.module.css";

export const MainPage = () => {
  const dispatch = useDispatch();
  const { planes, isLoading } = useSelector((state) => state.planes);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortOption, setSortOption] = useState("price"); 
  const [priceSortOrder, setPriceSortOrder] = useState("asc"); 
  const [capacitySortOrder, setCapacitySortOrder] = useState("asc"); 
  const [currentPage, setCurrentPage] = useState(1);
  const planesPerPage = 10; 

  useEffect(() => {
    dispatch(fetchPlanes());
  }, [dispatch]);

  const filteredPlanes = planes.filter((plane) =>
    plane.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    plane.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort based on selected criteria
  const sortedPlanes = [...filteredPlanes].sort((a, b) => {
    if (sortOption === "price") {
      return priceSortOrder === "asc" ? a.price - b.price : b.price - a.price;
    }
    if (sortOption === "capacity") {
      return capacitySortOrder === "asc"
        ? a.capacity - b.capacity
        : b.capacity - a.capacity;
    }
    if (sortOption === "name") {
      return a.name.localeCompare(b.name);
    }
    return 0;
  });

  // Reset page when filtering or sorting criteria change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, sortOption, priceSortOrder, capacitySortOrder, planes]);

  const indexOfLastPlane = currentPage * planesPerPage;
  const indexOfFirstPlane = indexOfLastPlane - planesPerPage;
  const currentPlanes = sortedPlanes.slice(indexOfFirstPlane, indexOfLastPlane);
  const totalPages = Math.ceil(filteredPlanes.length / planesPerPage);

  if (isLoading) {
    return <p>Loading...</p>;
  }

  return (
    <div id="mainContent">
      <div className={styles.sortContainer}>
        <input
          type="text"
          placeholder="Search for a plane..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className={styles.searchBar}
        />
        <div className={styles.sortPanel}>
          <div className={styles.sortFilters}>
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className={styles.sortDropdown}
            >
              <option value="price">Sort by Price</option>
              <option value="capacity">Sort by Capacity</option>
              <option value="name">Sort by Name</option>
            </select>
            {sortOption === "price" && (
              <span
                onClick={() =>
                  setPriceSortOrder((prev) => (prev === "asc" ? "desc" : "asc"))
                }
                className={styles.sortArrow}
                title="Toggle Price sort order"
              >
                {priceSortOrder === "asc" ? "↑" : "↓"}
              </span>
            )}
            {sortOption === "capacity" && (
              <span
                onClick={() =>
                  setCapacitySortOrder((prev) =>
                    prev === "asc" ? "desc" : "asc"
                  )
                }
                className={styles.sortArrow}
                title="Toggle Capacity sort order"
              >
                {capacitySortOrder === "asc" ? "↑" : "↓"}
              </span>
            )}
            {sortOption === "name" && (
              <span className={styles.sortArrowPlaceholder}></span>
            )}
          </div>
          <Link to={paths.createPlane} className={styles.createPlaneBtn}>
            Add a plane
          </Link>
        </div>
      </div>
      <div className={styles.planesGrid}>
        {currentPlanes.length > 0 ? (
          currentPlanes.map((plane) => (
            <PlaneItem key={plane._id} {...plane} />
          ))
        ) : (
          <p>No planes available.</p>
        )}
      </div>

      <div className={styles.pagination}>
        <button
          onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
          disabled={currentPage === 1}
          className={styles.pagButton}
        >
          Previous
        </button>
        <span className={styles.pagInfo}>
          Page {currentPage} of {totalPages}
        </span>
        <button
          onClick={() =>
            setCurrentPage((prev) => (currentPage < totalPages ? prev + 1 : prev))
          }
          disabled={currentPage === totalPages}
          className={styles.pagButton}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default MainPage;