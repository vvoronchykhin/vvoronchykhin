import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "../../components/button";
import { ContentWrapper } from "../../components/content-wrapper";
import styles from "./styles.module.css";

export const OrderPage = () => {
  const navigate = useNavigate();

  return (
    <ContentWrapper className={styles.order}>
      <h1>Your order will be delivered shortly</h1>
      <Button containerClassName={styles.button} onClick={() => navigate('/')}>
        Back to Home
      </Button>
    </ContentWrapper>
  );
};
