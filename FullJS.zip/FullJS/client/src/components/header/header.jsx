import React from 'react';
import { ContentWrapper } from '../content-wrapper';
import WaveImage from './wave.svg';
import styles from './styles.module.css';

export const Header = ({ onGetStarted }) => {

  return (
    <div className={styles.header}>
      <div className={styles.overlay} />
      <ContentWrapper className={styles.content}>
        <h1 className={styles.title}>Travel with Comfort</h1>
        <p className={styles.tagline}>
          Experience luxury travel, unbeatable service, and unforgettable journeys.
        </p>
        <p className={styles.desc}>
          Book your next flight and explore the world with premium deals and exclusive benefits.
        </p>
        <button className={styles.ctaButton} onClick={onGetStarted}>
          Get Started
        </button>
      </ContentWrapper>
      <img src={WaveImage} alt="Wave" className={styles.wave} />
    </div>
  );
};

export default Header;