import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchPlanes } from "../../store/plane/planeSlice";
import { Link, useNavigate } from "react-router-dom";
import { paths } from "../../paths";
import { PlaneItem } from "../plane-item";
import { Spinner } from "../spinner";
import axios from "axios";
import styles from "./styles.module.css";

export const Planes = () => {
  const dispatch = useDispatch();
  const { planes, isLoading } = useSelector((state) => state.planes);
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOption, setSortOption] = useState("price");
  const [priceSortOrder, setPriceSortOrder] = useState("asc");
  const [capacitySortOrder, setCapacitySortOrder] = useState("asc");
  const planesPerPage = 6;

  // Filter by search query
  const filteredPlanes = planes.filter((plane) =>
    plane.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    plane.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sort based on selected criteria
  const sortedPlanes = [...filteredPlanes].sort((a, b) => {
    if (sortOption === "price") {
      return priceSortOrder === "asc" ? a.price - b.price : b.price - a.price;
    }
    if (sortOption === "name") {
      return a.name.localeCompare(b.name);
    }
    if (sortOption === "capacity") {
      return capacitySortOrder === "asc"
        ? a.capacity - b.capacity
        : b.capacity - a.capacity;
    }
    return 0;
  });

  const indexOfLastPlane = currentPage * planesPerPage;
  const indexOfFirstPlane = indexOfLastPlane - planesPerPage;
  const currentPlanes = sortedPlanes.slice(indexOfFirstPlane, indexOfLastPlane);
  const totalPages = Math.ceil(filteredPlanes.length / planesPerPage);

  useEffect(() => {
    dispatch(fetchPlanes());
  }, [dispatch]);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/planes/${id}`);
      dispatch(fetchPlanes()); // Refresh the list after deletion
    } catch (err) {
      console.error("Error deleting plane:", err);
    }
  };

  if (isLoading) return <Spinner />;

  return (
    <div>
      <div className={styles.sort}>
        <input
          type="text"
          placeholder="Search for a plane..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className={styles.searchBar}
        />
        <div className={styles.sortPanel}>
          <select
            onChange={(e) => setSortOption(e.target.value)}
            className={styles.sortDropdown}
            value={sortOption}
          >
            <option value="price">Sort by Price</option>
            <option value="capacity">Sort by Capacity</option>
            <option value="name">Sort by Name</option>
          </select>
          {sortOption === "price" && (
            <span
              onClick={() =>
                setPriceSortOrder((prev) => (prev === "asc" ? "desc" : "asc"))
              }
              className={styles.sortArrow}
              title="Toggle Price sort order"
            >
              {priceSortOrder === "asc" ? "↑" : "↓"}
            </span>
          )}
          {sortOption === "capacity" && (
            <span
              onClick={() =>
                setCapacitySortOrder((prev) =>
                  prev === "asc" ? "desc" : "asc"
                )
              }
              className={styles.sortArrow}
              title="Toggle Capacity sort order"
            >
              {capacitySortOrder === "asc" ? "↑" : "↓"}
            </span>
          )}
        </div>
        <Link to={paths.createPlane} className={styles.createPlaneBtn}>
          Add a plane
        </Link>
      </div>
      <div className={styles.planesGrid}>
        {currentPlanes.length > 0 ? (
          currentPlanes.map((plane) => (
            <div key={plane._id} className={styles.planeCard}>
              <PlaneItem {...plane} />
              <button
                onClick={() => navigate(`/update-plane/${plane._id}`)}
                className={styles.updateButton}
              >
                Update
              </button>
              <button
                onClick={() => handleDelete(plane._id)}
                className={styles.deleteButton}
              >
                Delete
              </button>
            </div>
          ))
        ) : (
          <p>No planes available.</p>
        )}
      </div>
      <div className={styles.pagination}>
        <button
          onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
          disabled={currentPage === 1}
        >
          Previous
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button
          onClick={() =>
            setCurrentPage((prev) =>
              currentPage < totalPages ? prev + 1 : prev
            )
          }
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default Planes;