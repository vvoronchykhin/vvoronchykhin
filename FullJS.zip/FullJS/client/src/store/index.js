import { configureStore } from "@reduxjs/toolkit";
import planeReducer from "./plane/planeSlice"; 

const store = configureStore({
  reducer: {
    planes: planeReducer,
  },
});

export default store;