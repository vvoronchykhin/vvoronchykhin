import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const API_URL = process.env.REACT_APP_API_URL || ""; 

// Async thunk to fetch all planes
export const fetchPlanes = createAsyncThunk("planes/fetchPlanes", async () => {
  const response = await axios.get(`${API_URL}/planes`);
  return response.data;
});

// Async thunk to fetch a single plane by ID
export const getPlane = createAsyncThunk("planes/getPlane", async (id) => {
  const response = await axios.get(`${API_URL}/planes/${id}`);
  return response.data;
});

const planeSlice = createSlice({
  name: "planes",
  initialState: {
    planes: [],
    plane: null,
    isLoading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchPlanes.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(fetchPlanes.fulfilled, (state, action) => {
        state.isLoading = false;
        state.planes = action.payload;
      })
      .addCase(fetchPlanes.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      })
      .addCase(getPlane.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getPlane.fulfilled, (state, action) => {
        state.isLoading = false;
        state.plane = action.payload;
      })
      .addCase(getPlane.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.error.message;
      });
  },
});

export default planeSlice.reducer;

