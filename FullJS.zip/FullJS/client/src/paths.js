export const paths = {
    home: '/',
    plane: '/plane',
    createPlane: '/create-plane',
    order: '/order'
}